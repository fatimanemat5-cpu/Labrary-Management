#include <iostream>
#include <string>
using namespace std;

class Book
{
public:
    int id;
    string title;
    string author;
    bool issued;
};

Book books[100];
int countBook = 0;

// Add Book
void addBook()
{
    cout << "\nEnter Book ID: ";
    cin >> books[countBook].id;

    cin.ignore();

    cout << "Enter Book Title: ";
    getline(cin, books[countBook].title);

    cout << "Enter Author Name: ";
    getline(cin, books[countBook].author);

    books[countBook].issued = false;

    countBook++;

    cout << "Book Added Successfully!\n";
}

// Display Books
void displayBooks()
{
    if(countBook == 0)
    {
        cout << "No Books Available!\n";
        return;
    }

    cout << "\nLibrary Books:\n";

    for(int i = 0; i < countBook; i++)
    {
        cout << "\nBook ID: " << books[i].id << endl;
        cout << "Title: " << books[i].title << endl;
        cout << "Author: " << books[i].author << endl;

        if(books[i].issued)
            cout << "Status: Issued\n";
        else
            cout << "Status: Available\n";
    }
}

// Search Book
void searchBook()
{
    string name;
    bool found = false;

    cin.ignore();

    cout << "\nEnter Book Title to Search: ";
    getline(cin, name);

    for(int i = 0; i < countBook; i++)
    {
        if(name == books[i].title)
        {
            cout << "\nBook Found!\n";
            cout << "Book ID: " << books[i].id << endl;
            cout << "Author: " << books[i].author << endl;

            found = true;
        }
    }

    if(!found)
        cout << "Book Not Found!\n";
}

// Issue Book
void issueBook()
{
    int id;

    cout << "\nEnter Book ID to Issue: ";
    cin >> id;

    for(int i = 0; i < countBook; i++)
    {
        if(books[i].id == id)
        {
            if(!books[i].issued)
            {
                books[i].issued = true;
                cout << "Book Issued Successfully!\n";
            }
            else
            {
                cout << "Book Already Issued!\n";
            }

            return;
        }
    }

    cout << "Book ID Not Found!\n";
}

// Return Book
void returnBook()
{
    int id;

    cout << "\nEnter Book ID to Return: ";
    cin >> id;

    for(int i = 0; i < countBook; i++)
    {
        if(books[i].id == id)
        {
            if(books[i].issued)
            {
                books[i].issued = false;
                cout << "Book Returned Successfully!\n";
            }
            else
            {
                cout << "Book was not issued!\n";
            }

            return;
        }
    }

    cout << "Book ID Not Found!\n";
}

// Main Function
int main()
{
    int choice;

    while(true)
    {
        cout << "\n===== LIBRARY MANAGEMENT SYSTEM =====\n";
        cout << "1. Add Book\n";
        cout << "2. Display Books\n";
        cout << "3. Search Book\n";
        cout << "4. Issue Book\n";
        cout << "5. Return Book\n";
        cout << "6. Exit\n";

        cout << "Enter Your Choice: ";
        cin >> choice;

        switch(choice)
        {
            case 1:
                addBook();
                break;

            case 2:
                displayBooks();
                break;

            case 3:
                searchBook();
                break;

            case 4:
                issueBook();
                break;

            case 5:
                returnBook();
                break;

            case 6:
                cout << "Exiting Program...\n";
                return 0;

            default:
                cout << "Invalid Choice!\n";
        }
    }

    return 0;
}